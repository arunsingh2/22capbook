package com.cg.capbook.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class URIController {
	@RequestMapping("/")
    public String getIndexPage() {
        return "indexPage";
    }
	 @RequestMapping("/user")
	    public String getRegistrationPage() {
	        return "userPage";
	    }
	 @RequestMapping("/login")
	    public String getloginPage() {
	        return "loginPage";
	    }
	 @RequestMapping("/profile")
	    public String getprofilePage() {
	        return "profilePage";
	    }
	 @RequestMapping("/forgot")
	    public String getverificationpasswordPage() {
	        return "forgotPasswordPage";
	    }
	 @RequestMapping("/chage")
	 public String getchagepasswordPage() {
	        return "chagePasswordPage";
	    }
	 @RequestMapping("/addFr")
	 public String getaddFriendPage() {
	        return "addFriendPage";
	    }
	
	

}
