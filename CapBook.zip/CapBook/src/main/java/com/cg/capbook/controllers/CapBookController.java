package com.cg.capbook.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Friend;
import com.cg.capbook.beans.Profile;
import com.cg.capbook.exceptions.EmailAlreadyUsedException;
import com.cg.capbook.exceptions.FriendshipAlreadyExistsException;
import com.cg.capbook.exceptions.InvalidEmailIdException;
import com.cg.capbook.exceptions.InvalidPasswordException;
import com.cg.capbook.exceptions.NoUserFoundException;
import com.cg.capbook.exceptions.RequestAlreadyReceivedException;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.UserAuthenticationFailedException;
import com.cg.capbook.services.CapBookServices;
import com.cg.capbook.services.StorageService;

@Controller
public class CapBookController {
	@RequestMapping("/hello")
	@ResponseBody
	public String sayHello()
	{
		return "hello this is arun";
	}
	@Autowired
	private CapBookServices capBookServices;
	@Autowired
	private StorageService storageService;

	@RequestMapping("/registerUser")
	public ModelAndView registerUser(@ModelAttribute Profile profile) throws EmailAlreadyUsedException {
		profile=capBookServices.registerUser(profile);
		return new ModelAndView("registrationSuccessPage","profile",profile);
	}
//	@RequestMapping(value="/loginUser",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
//	ResponseEntity<Profile> loginUser (@RequestBody Profile profile) throws InvalidEmailIdException, InvalidPasswordException {
//		profile=capBookServices.loginUser(profile);	
//		return new ResponseEntity<Profile>(profile,HttpStatus.OK);
//	}
	@RequestMapping("/loginUser")
	public ModelAndView loginUser(@ModelAttribute Profile profile) throws InvalidEmailIdException, InvalidPasswordException {
		profile=capBookServices.loginUser(profile);	
		return new ModelAndView("profilePage","profile",profile);
	}
//	@RequestMapping(value="/logout",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
//	ResponseEntity<Profile> loginUser () throws InvalidEmailIdException, InvalidPasswordException {
//		Profile profile=capBookServices.logout();	
//		System.out.println("done");
//		return new ResponseEntity<Profile>(profile,HttpStatus.OK);
//	}
	@RequestMapping("/profileUser")
	@ResponseBody()
	public ModelAndView logoutUser(@ModelAttribute Profile profile) throws InvalidEmailIdException, InvalidPasswordException {
		profile=capBookServices.logout();	
		return new ModelAndView("loginPage","profile",profile);
	}
//	@RequestMapping(value="/forgotPassword",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
//	ResponseEntity<Profile> forgotPassword(@RequestBody Profile profile) throws InvalidEmailIdException, UserAuthenticationFailedException {
//		String password=capBookServices.forgotPassword(profile.getEmailId(),profile.getSecurityQuestion(),profile.getSecurityAnswer());
//		profile.setPassword(password);
//		return new ResponseEntity<Profile>(profile,HttpStatus.OK);
//	}
	@RequestMapping("/securityPasswordUser")
	public ModelAndView forgotPassword(@ModelAttribute Profile profile) throws InvalidEmailIdException, InvalidPasswordException, UserAuthenticationFailedException {
		String password=capBookServices.forgotPassword(profile.getEmailId(),profile.getSecurityQuestion(),profile.getSecurityAnswer());
		profile.setPassword(password);
		return new ModelAndView("passwordChangeSuccessPage","profile",profile);
	}
//	@RequestMapping(value="/changePassword",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
//	ResponseEntity<Profile> changePassword(@RequestParam("password")String password) throws InvalidEmailIdException, InvalidPasswordException{
//		Profile profile= capBookServices.changePassword(password);
//		return new ResponseEntity<Profile>(profile,HttpStatus.OK);
//	}
//	
	@RequestMapping("/changepasswordUser")
	@ResponseBody()
	public ModelAndView changePassword(String password) throws InvalidEmailIdException, InvalidPasswordException {
		Profile profile= capBookServices.changePassword(password);
		return new ModelAndView("passwordChangeSuccessPage","profile",profile);
	}
//	@RequestMapping(value="/editProfile",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
//	ResponseEntity<Profile> editProfile(@RequestBody Profile profile) throws InvalidEmailIdException{	
//		profile=capBookServices.editProfile(profile);
//		return new ResponseEntity<Profile>(profile,HttpStatus.OK);
//	}
	@RequestMapping("/editProfile")
	public ModelAndView editProfile(@ModelAttribute Profile profile) throws InvalidEmailIdException {
		profile=capBookServices.editProfile(profile);
		return new ModelAndView("profileeditSuccessPage","profile",profile);
	}
//	@RequestMapping(value="/findUsers",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
//	ResponseEntity<List<Profile>> findUsers(@RequestParam("name") String userName) throws NoUserFoundException{	
//		List<Profile>listUser=null;		
//		listUser=capBookServices.searchAllUsersByName(userName);
//		return new ResponseEntity<List<Profile>>(listUser,HttpStatus.OK);
//	}
	@RequestMapping("/findUsers")
	@ResponseBody()
	public  List findUsers(String userName) throws NoUserFoundException {
		userName="Arun";
		List<Profile>listUser=null;		
	 listUser=capBookServices.searchAllUsersByName(userName);
		return listUser;
	}
//	@RequestMapping(value="/addFriend",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
//	ResponseEntity<Friend> addFriend(@RequestParam("toUserId") String toUserId) throws FriendshipAlreadyExistsException, RequestAlreadyReceivedException, RequestAlreadySentException{			
//		Friend friend=capBookServices.addFriend(toUserId);
//		return new ResponseEntity<Friend>(friend,HttpStatus.OK);
//	}
	@RequestMapping("/addFriend")
	@ResponseBody()
	public  ModelAndView addFriend(String toUserId) throws FriendshipAlreadyExistsException, RequestAlreadyReceivedException, RequestAlreadySentException  {
		toUserId="Arun";
		Friend friend=capBookServices.addFriend(toUserId);
		return new ModelAndView("addFriendSuccessPage","friend",friend);
	
		
	}
}
