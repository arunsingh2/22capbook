package com.cg.capbook.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Friend;
import com.cg.capbook.beans.Message;
import com.cg.capbook.beans.Notification;
import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.Profile;
import com.cg.capbook.exceptions.EmailAlreadyUsedException;
import com.cg.capbook.exceptions.FriendshipAlreadyExistsException;
import com.cg.capbook.exceptions.InvalidEmailIdException;
import com.cg.capbook.exceptions.InvalidPasswordException;
import com.cg.capbook.exceptions.NoUserFoundException;
import com.cg.capbook.exceptions.RequestAlreadyReceivedException;
import com.cg.capbook.exceptions.RequestAlreadySentException;

import com.cg.capbook.exceptions.UserAuthenticationFailedException;

import com.cg.capbook.services.CapBookServices;
import com.cg.capbook.services.StorageService;

@Controller
public class CapBookController {
	
	@Autowired
	private CapBookServices capBookServices;
	@Autowired
	private StorageService storageService;

	@RequestMapping("/registerUser")
	public ModelAndView registerUser(@ModelAttribute Profile profile) throws EmailAlreadyUsedException {
		profile=capBookServices.registerUser(profile);
		return new ModelAndView("registrationSuccessPage","profile",profile);
	}

	@RequestMapping("/loginUser")
	public ModelAndView loginUser(@ModelAttribute Profile profile) throws InvalidEmailIdException, InvalidPasswordException {
		profile=capBookServices.loginUser(profile);	
		return new ModelAndView("ProfilePage","profile",profile);
	}

	@RequestMapping("/logoutUser")
	@ResponseBody()
	public ModelAndView logoutUser(@ModelAttribute Profile profile) throws InvalidEmailIdException, InvalidPasswordException {
		profile=capBookServices.logout();	
		return new ModelAndView("WelcomePage","profile",profile);
	}

	@RequestMapping("/securityPasswordUser")
	public ModelAndView forgotPassword(@ModelAttribute Profile profile) throws InvalidEmailIdException, InvalidPasswordException, UserAuthenticationFailedException {
		String password=capBookServices.forgotPassword(profile.getEmailId(),profile.getSecurityQuestion(),profile.getSecurityAnswer());
		profile.setPassword(password);
		return new ModelAndView("forgotpasswordSuccessPage","profile",profile);
	}

	@RequestMapping("/changepasswordUser")
	@ResponseBody()
	public ModelAndView changePassword(String password) throws InvalidEmailIdException, InvalidPasswordException {
		Profile profile= capBookServices.changePassword(password);
		return new ModelAndView("passwordChangeSuccessPage","profile",profile);
	}

	@RequestMapping("/editProfile")
	public ModelAndView editProfile(@ModelAttribute Profile profile) throws InvalidEmailIdException {
		profile=capBookServices.editProfile(profile);
		return new ModelAndView("profileeditSuccessPage","profile",profile);
	}
//	@RequestMapping(value="/findUsers",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
//	ResponseEntity<List<Profile>> findUsers(@RequestParam("name") String userName) throws NoUserFoundException{	
//		List<Profile>listUser=null;		
//		listUser=capBookServices.searchAllUsersByName(userName);
//		return new ResponseEntity<List<Profile>>(listUser,HttpStatus.OK);
//	}
//	@RequestMapping("/findUsers")
//	@ResponseBody()
//	public  List findUsers(String userName) throws NoUserFoundException {
//		//userName="Arun";
//		List<Profile>listUser=null;		
//	 listUser=capBookServices.searchAllUsersByName(userName);
//		return listUser;
//	}
	@RequestMapping("/findUsers")
	@ResponseBody()
	public ModelAndView findUsers(@ModelAttribute String userName) throws NoUserFoundException {
		List<Profile>profile=null;	
		userName="arun";
	 profile=capBookServices.searchAllUsersByName(userName);
	 
		return new ModelAndView("findUserSuccssPage","profile",profile);
	}

	@RequestMapping("/addFriend")
	@ResponseBody()
	public  ModelAndView addFriend(String toUserId) throws FriendshipAlreadyExistsException, RequestAlreadyReceivedException, RequestAlreadySentException  {
		Friend friend=capBookServices.addFriend(toUserId);
		return new ModelAndView("addFriendSuccessPage","friend",friend);
	

	}
		@RequestMapping("/viewFriendRequests")
		@ResponseBody()

		public ModelAndView  viewFriendRequests(@ModelAttribute Profile profile)  throws FriendshipAlreadyExistsException, RequestAlreadyReceivedException, RequestAlreadySentException{
			List<Profile> friendRequests=capBookServices.viewFriendRequests();	
			return new ModelAndView("viewFriendRequestPage","friendRequests",friendRequests);
		
		
		}

		
		@RequestMapping("/acceptFriend")
		public ModelAndView acceptFriend(@ModelAttribute Friend friend) throws RequestAlreadySentException{
			friend=capBookServices.acceptFriend(friend.getToUserId());
			return new ModelAndView("acceptFriendPage","friend",friend);
		}

		@RequestMapping("/rejectFriend")
		public ModelAndView rejectFriend(@ModelAttribute Friend friend) throws RequestAlreadySentException{
			friend=capBookServices.rejectFriend(friend.getFromUserId(),friend.getToUserId());
			return new ModelAndView("rejectFriendPage","friend",friend);
		}

		@RequestMapping("/getFriendList")
		@ResponseBody()
		public ModelAndView getFriendList()  {
			List<Profile>friendList=capBookServices.getFriendList();
			return new ModelAndView("getFriendListPage","friendList",friendList);
			//return friendList;
		}
		

		@RequestMapping("/sendMessage")
		public ModelAndView sendMessage(@RequestParam String message1,String receiverEmailId) throws RequestAlreadySentException{
			Message sendMessage = new Message();
		 sendMessage.setMessage(message1);
			sendMessage.setReceiverEmailId(receiverEmailId);
		capBookServices.sendMessage(sendMessage);
			return new ModelAndView("chatbot","message1",message1);
		}

		@RequestMapping("/viewSentMessages")
		@ResponseBody
		public ModelAndView viewSentMessages(){
			List<Message> messages=capBookServices.viewSentMessages();
			return new ModelAndView("viewSentMessagesPage","messages",messages);
			//return messages;
		}

		@RequestMapping("/viewReceivedMessages")
		@ResponseBody
		public ModelAndView viewReceivedMessages(){
			List<Message> mess=capBookServices.viewReceivedMessages();
			return new ModelAndView("viewRecievedMessages","mess",mess);
		}
		
//		@PostMapping(value="/setProfilePic",consumes= {MediaType.ALL_VALUE},produces=MediaType.ALL_VALUE)
//		public ResponseEntity<byte[]> setImage(@RequestParam("Image") MultipartFile image) throws IOException {
//			System.out.println("Image");
//			storageService.store(image);
//			//File file1=(File) storageService.loadFile(image.getOriginalFilename());
//			File file=new File("D:\\java\\finalProject\\userImages"+image.getOriginalFilename());
//			//System.out.println(file);
//			image.transferTo(file);
//			//System.out.println(file);
//			FileInputStream fin=new FileInputStream(file);
//			//System.out.println(file);
//			byte[] bytes = StreamUtils.copyToByteArray(fin);
//			capBookServices.insertProfilePic(bytes);
//			System.out.println(bytes);
//			return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(bytes);
		//}
//		@PostMapping(value="/setProfilePic")
//		public ModelAndView setImage(MultipartFile image) throws IOException{
//			System.out.println("Image");
//			storageService.store(image);
//		//File file1=(File) storageService.loadFile(image.getOriginalFilename());C:\Users\Public\Pictures
//			File file=new File("C:\\Users\\Public\\Pictures\\Sample Pictures"+image.getOriginalFilename());
//		//System.out.println(file);
//		image.transferTo(file);
//			//System.out.println(file);
//			FileInputStream fin=new FileInputStream(file);
//			//System.out.println(file);
//			String bytes = null;
//			capBookServices.insertProfilePic(bytes);
//			System.out.println(bytes);
//			return new ModelAndView("profileImagesetSuccessPage","byte",bytes);
//			
//		}

		
		@RequestMapping("/getPosts")
		@ResponseBody
		public ModelAndView getPosts(){
			List<Post> posts=capBookServices.getPosts();
			return new ModelAndView("getPostPage","posts",posts);
		}

		@RequestMapping("/createPost")
		@ResponseBody()
		public ModelAndView logoutUser(@ModelAttribute Post post,@RequestParam MultipartFile file) throws InvalidEmailIdException, InvalidPasswordException, IllegalStateException, IOException {
			capBookServices.createPost(post, file);
			return new ModelAndView("PostSuccessPage","post",post);
		}
//		@RequestMapping(value="/getNotifications",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
//		ResponseEntity<List<Notification>> getNotifications(){			
//			List<Notification> notifications=capBookServices.getNotifications();
//			return new ResponseEntity<List<Notification>>(notifications,HttpStatus.OK);
//		}

		
		@RequestMapping("/getNotifications")
		@ResponseBody
		public ModelAndView getNotifications(){
			List<Notification> notifications=capBookServices.getNotifications();
			return new ModelAndView("GetNotificationPage","notifications",notifications);
		}
		@RequestMapping("/UploadServlet")
		@ResponseBody()
		public ModelAndView UploadServlet(@RequestParam("file") MultipartFile file) {
			
			return new ModelAndView("photosuccesspage","file",file);
		}
		// @PostMapping("/uploadFile")
//		    public UploadFileResponse uploadFile(@RequestParam("file") MultipartFile file) {
//		        String fileName = fileStorageService.storeFile(file);
//
//		        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
//		                .path("/downloadFile/")
//		                .path(fileName)
//		                .toUriString();
//
//		        return new UploadFileResponse(fileName, fileDownloadUri,
//		                file.getContentType(), file.getSize());
//	}
		@RequestMapping("/getProfile")
		@ResponseBody
		public ModelAndView getProfile(@RequestParam String emailId) throws InvalidEmailIdException{
			Profile profile=capBookServices.getProfile(emailId);
			return new ModelAndView("ProfilePage","profile",profile);
		}	
//		@RequestMapping("/fetchProfilepic")
//		@ResponseBody
//		public ModelAndView getProfile(){
//			String profile=capBookServices.fetchProfilePic();
//			return new ModelAndView("FetchProfilePic","profilepic",profile);
//		}
		 @RequestMapping("/updatePic") public ModelAndView updatePic( @RequestParam MultipartFile file,  Profile user) throws NoUserFoundException, IOException {
				user=capBookServices.addProfilePic(user.getEmailId(), file);
				return new ModelAndView("EditProfilePage","user",user);
			}
}