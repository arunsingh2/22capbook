package com.cg.capbook.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class URIController {
//	@RequestMapping("/")
//    public String getIndexPage() {
//        return "indexPage";
//    }
	 @RequestMapping(value={"/","/welcome"})
	    public String getRegistrationPage() {
	        return "WelcomePage";
	    }
	 @RequestMapping("/login")
	    public String getloginPage() {
	        return "loginPage";
	    }
	 @RequestMapping("/profile")
	    public String getprofilePage() {
	        return "profilePage";
	    }
	 @RequestMapping("/forgot")
	    public String getverificationpasswordPage() {
	        return "forgotpasswordPage";
	    }
	 @RequestMapping("/regis")
	    public String getregistrationPage() {
	        return "registrationPage";
	    }
	 @RequestMapping("/chage")
	 public String getchagepasswordPage() {
	        return "chagePasswordPage";
	    }
	 @RequestMapping("/addFr")
	 public String getaddFriendPage() {
	        return "addFriendPage";
	    }
	
	 @RequestMapping("/userlist")
	    public String getuserPage() {
	        return "findUserSuccssPage";
	    }
	 @RequestMapping("/editprofil")
	    public String geteditProfilePage() {
	        return "EditProfilePage";
	    }
	 @RequestMapping("/changePass")
	    public String changePass() {
	        return "ChagePasswordPage";
	    }
	 @RequestMapping("/chatobot")
	    public String chatobot() {
	        return "chatbot";
	    }
	 @RequestMapping("/edProfpicPage")
	    public String edProfpicPage() {
	        return "EditProfilePicturePage";
	    }
	 @RequestMapping("/nprofilePage")
	    public String getnewProfilePage() {
	        return "NProfilepage";
	    }
	
	 @RequestMapping("/profilepg")
	    public String getProfilePage() {
	        return "ProfilePage";
	    }
	 @RequestMapping("/viewreci")
	    public String getRecievedMessagePage() {
	        return "chatbot";
	    }

 @RequestMapping("/cretpost")
    public String getcreatepostPage() {
        return "CreatePostPage";
    }
 @RequestMapping("/setProfPic")
 public String getsetProfilepicPage() {
     return "profilePic";
 }
// @RequestMapping("/recieved")
// public String getmessageRecievedPage() {
//     return "viewRecievedMessages";
// }
// @RequestMapping("/getFriendLis")
// public String getFriendListPage() {
//     return "FriendListPage";
 //}
}
