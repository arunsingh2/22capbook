package com.cg.capbook.aspect;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Profile;
import com.cg.capbook.customresponse.CustomResponse;
import com.cg.capbook.exceptions.EmailAlreadyUsedException;
import com.cg.capbook.exceptions.FriendshipAlreadyExistsException;
import com.cg.capbook.exceptions.InvalidEmailIdException;
import com.cg.capbook.exceptions.InvalidPasswordException;
import com.cg.capbook.exceptions.NoUserFoundException;
import com.cg.capbook.exceptions.RequestAlreadyReceivedException;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.UserAlreadyYourFriendException;
import com.cg.capbook.exceptions.UserAuthenticationFailedException;

//@ControllerAdvice(basePackages= {"com.cg.capbook.controllers"})
@ControllerAdvice
public class CapBookExceptionAspect {
	@ExceptionHandler(EmailAlreadyUsedException.class)
	public ModelAndView handleInvalidEmailIdException(Exception e) {
	ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
	modelAndView.addObject("profile", new Profile());
		return modelAndView;
	}
	@ExceptionHandler(InvalidPasswordException.class)
	public ModelAndView handleInvalidPasswordException(Exception e) {
	ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
	modelAndView.addObject("profile", new Profile());
		return modelAndView;
	}
	
	@ExceptionHandler(NoUserFoundException.class)
	public ModelAndView handleNoUserFoundException(Exception e) {
	ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
	modelAndView.addObject("profile", new Profile());
		return modelAndView;
	}
	@ExceptionHandler(RequestAlreadyReceivedException.class)
	public ModelAndView handleRequestAlreadyReceivedException(Exception e) {
	ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
	modelAndView.addObject("profile", new Profile());
		return modelAndView;
	}
	@ExceptionHandler(UserAlreadyYourFriendException.class)
	public ModelAndView handleUserAlreadyYourFriendException(Exception e) {
	ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
	modelAndView.addObject("profile", new Profile());
		return modelAndView;
	}
	@ExceptionHandler(UserAuthenticationFailedException.class)
	public ModelAndView handleUserAuthenticationFailedException(Exception e) {
	ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
	modelAndView.addObject("profile", new Profile());
		return modelAndView;
	}



}





