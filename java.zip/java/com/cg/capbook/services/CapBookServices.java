package com.cg.capbook.services;
import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.Comment;
import com.cg.capbook.beans.Friend;
import com.cg.capbook.beans.Message;
import com.cg.capbook.beans.Notification;
import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.Profile;
import com.cg.capbook.exceptions.EmailAlreadyUsedException;
import com.cg.capbook.exceptions.FriendshipAlreadyExistsException;
import com.cg.capbook.exceptions.InvalidEmailIdException;
import com.cg.capbook.exceptions.InvalidPasswordException;
import com.cg.capbook.exceptions.NoUserFoundException;
import com.cg.capbook.exceptions.RequestAlreadyReceivedException;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.UserAuthenticationFailedException;
public interface CapBookServices {
	Profile registerUser(Profile profile) throws EmailAlreadyUsedException;
	Profile loginUser(Profile profile) throws InvalidEmailIdException,InvalidPasswordException;
	Profile logout();
	Profile editProfile(Profile profile) throws InvalidEmailIdException;
	List<Profile> searchAllUsersByName(String userName) throws  NoUserFoundException;
	void sendMessage(Message message);
	List<Message> viewSentMessages();
	List<Message> viewReceivedMessages();
	Friend addFriend(String toUserId) throws FriendshipAlreadyExistsException, RequestAlreadyReceivedException, RequestAlreadySentException;
	Profile getProfile(String emailId) throws InvalidEmailIdException;
	//Profile insertProfilePic(String profilePic);
	//String fetchProfilePic();
	Friend acceptFriend(String fromUserId) throws RequestAlreadySentException;
	List<Profile> viewFriendRequests();
	Profile changePassword(String newPassword) throws InvalidEmailIdException, InvalidPasswordException;
	Friend rejectFriend(String fromUserId, String toUserId) throws RequestAlreadySentException;
	List<Profile> getFriendList();
	String forgotPassword(String emailId, String securityQuestion, String securityAnswer)throws InvalidEmailIdException, UserAuthenticationFailedException;
	Post createPost(Post post,MultipartFile file) throws IllegalStateException, IOException;
	Post updatePostLikes(Post post);
	Post updatePostDislikes(Post post);
	Post addPostComment(Comment comment);
	List<Post> getPosts();
	List<Notification> getNotifications();
	Profile addProfilePic(String emailId, MultipartFile file) throws NoUserFoundException;
	//Post createPost(Post post, MultipartFile file);

	
}
