package com.cg.capbook.services;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.Post;
@Service
public class StorageService {
	private final Path rootLocation=Paths.get("D:\\3000198_Arun_Singh\\JavaFSfinalProject\\CapBook\\src\\main\\resources\\static\\images\\");
	public void store(MultipartFile file) {
		try {
			//Files.copy(
					//file.getInputStream(),this.rootLocation.resolve(file.getOriginalFilename()));
			file.transferTo(Paths.get(file.getOriginalFilename()));
//			System.out.println(file.getOriginalFilename());
//			Post image=new Post( "resources/images/UserImages/"+file.getOriginalFilename());
//			imageList.add(image);
//			album.setImages(imageList);
			//album.getImages().add(0,image);
			
		}catch(Exception e) {
			throw new RuntimeException("fail");
		}
	}
}
